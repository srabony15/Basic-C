long factorial(long n){
    long i, fact=1;
    for(i=1;i<=n;i++){
        fact *=i;
    }
    return fact;
}
int main(){
long n, result;
printf("Enter a number:");
scanf("%1d",&n);
result=factorial(n);
printf("factorial of %1d is %1d",n,result);
return 0;
}
