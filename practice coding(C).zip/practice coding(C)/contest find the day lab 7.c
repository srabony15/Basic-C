#include<stdio.h>
int main()
{
    int s,da;
    char ch[8][13]={"Saturday","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday"};
    scanf("%d",&s);
    da=s%7;
    if(da==0)
        da=7;
    printf("%s",ch[da-1]);
    return 0;
}
