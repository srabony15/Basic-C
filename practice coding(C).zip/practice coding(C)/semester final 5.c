#include<stdio.h>
int fibonacci(int n);
int main(){
int n,c;
printf("Enter value for Fibonacci series:");
scanf("%d",&n);
printf("Fibonacci series till %d terms\n",n);
for (c=0;c<n;c++)
{
    int result=fibonacci(c);
    printf("%d",result);
}
return 0;
}
int fibonacci(int n){
    if(n<2)
        return n;
    return fibonacci(n-1)+fibonacci(n-2);
}














