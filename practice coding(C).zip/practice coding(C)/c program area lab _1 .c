#include<stdio.h>
#define pi 3.1416
int main()
{
    float r,area;
    r=5;
    area=pi*r*r;
    printf("The area is:%f",area);

    return 0;
}
