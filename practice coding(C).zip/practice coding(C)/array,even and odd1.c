#include<stdio.h>
int main()
{
    float x[100],sum=0;
    int i;
    printf("Enter the numbers:");
    for(i=0;i<n;i++)
        scanf("%f",&x[i]);
    for(i=0;i<n;i++)
        Even=x[i];
    printf("Even=%.2f,odd=%.2f");
    return 0;

}
