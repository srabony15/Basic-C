#include<stdio.h>
int main()
{
    int r,c,n;
    printf("Enter the digit:");
    scanf("%d",&n);
    {
        for(r=1; r<=4; r++){
            for(c=1; c<=r; c++){
                printf("%d",c);
            }
            printf("\n");
        }
    }
    return 0;
}
