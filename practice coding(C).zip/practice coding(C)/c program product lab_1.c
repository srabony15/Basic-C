#include<stdio.h>
int main()
{
    int x,y,product;
    x=10;
    y=8;
    product=x*y;
    printf("product:%d",product);
    return 0;
}
