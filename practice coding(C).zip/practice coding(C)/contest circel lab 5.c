#include<stdio.h>
int main()
{
    float n,i,j;
    scanf("%f",&n);
    i=2*n;
    j=i*i-3.14159*n*n;
    printf("%.2f",j);
    return 0;
}
