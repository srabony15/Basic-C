#include<stdio.h>
int main()
{
    int a[100],n,c,x,y;
    printf("Enter the size of array:");
    scanf("%d",&n);
    y=n-1;
    printf("Enter the array:");
    for(c=0;c<n;c++)
    {
        scanf("%d",&a[c]);
    }
    for(c=0;c<n/2;c++)
    {
        x=a[c];
        a[c]=a[y];
        a[y]=x;
        y--;
    }
    printf("Reversed array is :");
    for(c=0;c<n;c++)
    {
        printf("%d",a[c]);
    }
    return 0;
}
