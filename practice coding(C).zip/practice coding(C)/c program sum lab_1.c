#include<stdio.h>
int main()
{
    int x,y,sum;
    x=5;
    y=7;
    sum=x+y;
    printf("summation:%d",sum);
    return 0;
}
