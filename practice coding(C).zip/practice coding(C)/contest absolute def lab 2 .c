#include<stdio.h>
int main()
{
    int i,j,k;
    printf("");
    scanf("%d",&i);
    printf("");
    scanf("%d",&j);
    if(i>j)
    {
        k=i-j;
    }
    else
    {
        k=j-i;
    }
    printf("Perbedaan = %d",k);
    return 0;
}
