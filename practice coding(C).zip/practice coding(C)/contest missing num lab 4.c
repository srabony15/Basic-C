#include<stdio.h>
int main()
{
    int A,B,C,D,X;
    scanf("%d%d%d%d",&A,&B,&C,&D);
    X=D-(A+B+C);
    printf("%d",X);
    return 0;
}
