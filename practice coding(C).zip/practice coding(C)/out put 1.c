#include<stdio.h>
void main()
{
    int digit;
    printf("Input digit(1):");
    scanf("%d",&digit);
    switch(digit)
    {



    case 1:
        printf("one\n");
        break;
    default:
        printf("invalid digit:");
        break;
    }
}
