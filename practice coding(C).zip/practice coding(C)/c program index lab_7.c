#include<stdio.h>
int searchitem(int arr[],int n,int p)
{
    int i;
    for(i=0;i<n;i++)
    {
        if(arr[i]==p)
        {
            return i;
        }

    }
    return -1;
}
int main()
{
    int arr[50];
    int i,n,p,result;
    printf("Enter any number for n:");
    scanf("%d",&n);
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    printf("Enter the search item:");
    scanf("%d",&p);
    result=searchitem(arr,n,p);
    if(result==-1)
        printf("item not found");
    else
        printf("index position =%d",result);
}
