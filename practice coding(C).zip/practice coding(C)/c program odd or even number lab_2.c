#include<stdio.h>
int main()
{
    int num,remainder;
    num=12;remainder=num%4;
    if("remainder=0"){
        printf("The number is odd:\n");
    }
    else{
        printf("The number is even:\n");
    }
    return 0;
}

