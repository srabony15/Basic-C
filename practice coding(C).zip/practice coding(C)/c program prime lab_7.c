#include<stdio.h>
int main()
{
    int y,i;
    printf("Enter two number: ");
    scanf("%d",&y);
    for(i=2;i<=y-1;i++)
        if(y%i==0)
        break;
    if(i==y)
        printf("prime numbers",y);
    else
        printf("not prime",y);
    return 0;
}
