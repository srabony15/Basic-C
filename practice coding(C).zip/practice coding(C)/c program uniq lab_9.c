#include <stdio.h>
int main()
{
    int arr[5],c;
    for(int i=0;i<5;i++)
    {
        scanf("%d",&arr[i]);
    }
    for(int i=0;i<5;i++)
    {
        c=0;
        for(int j=0;j<i;j++)
        {
            if(arr[i]==arr[j])
            {
                c=1;
                break;
            }
        }
        if(c==0)
            printf("%d",arr[i]);
    }
    return 0;


    }
