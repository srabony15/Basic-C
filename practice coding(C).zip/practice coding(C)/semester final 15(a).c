#include<stdio.h>
#include<stdio.h>
int main()
{
    FILE * fptr;
    char ch;
    fptr=fopen("content.text","r");
    if(fptr==NULL)
    {
        printf("ERROR.\n");

    }
    printf("File is opened !\n\n");
    do
    {
        ch=fgetc(fptr);
        putchar(ch);
     }   while(ch!=EOF);
    fclose(fptr);
    return 0;
}
