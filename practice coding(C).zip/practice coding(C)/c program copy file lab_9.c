#include<stdio.h>
int main()
{
    FILE*fp1,*fp2;
    char ch;
    fp1=fopen("input.text","r");
    fp2=fopen("output.text","w");
    ch=fgetc(fp1);
    while(ch!=EOF)
    {
        fputc(ch,fp2);
        ch=fgetc(fp1);
    }
    fclose(fp1);
    fclose(fp2);

}
