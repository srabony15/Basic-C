#include<stdio.h>
int main()
{
    int a,b,c=0;
    printf("Enter the number:");
    scanf("%d", &a);
    b=a %10;
    c=c *10+b;
    a/=10;

    b=a %10;
    c=c *10+b;
    a/=10;

    b=a %10;
    c=c *10+b;

    printf("Reversed number: %d\n",c);
    return 0;
}
