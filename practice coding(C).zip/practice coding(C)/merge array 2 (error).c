#include<stdio.h>
#define Max_SIZE 100
int main()
{
    int mergearray , arr1, [ MAX_SIZE],  arr2[  MAX_SIZE] ,mergearray[MAX_SIZE * 2];
    int size1,size2,mergesize;
    int index1,index2,mergeIndex;
    int i;
    printf("Enter the size of first array:");
    scanf("%d",&size1);
    printf("Enter elements in first array:");
    for (i=0;i<size1;i++)
    {
        scanf("%d",&arr1[i]);
    }
    printf("\nEnter the size of second array:");
    for(i=0;i<size2;i++)
    {
        scanf("%d",&arr2[i]);
    }
    mergesize =size1+size2;
    index1=0;
    index2=0;
    for (mergeindex=0;mergeindex<mergesize;mer)
    {
        if(index1>=size1||index2>=size2)
        {
            break;
        }
        if(arr1[index1]<arr2[index2])
        {
            mergearray[mergeindex]=arr1[index1]
            index1++;
        }
        else
        {
            mergearray[mergeindex]=arr2[index2]
            index2++;
        }
    }
    while (index1<size2)
    {
        mergearray[mergeindex]=arr1[index1];
        mergeindex;
    }
    while(index2<size2)
    {
        mergearray[mergeindex]=arr2[index2];
        mergeindex++;
    }
    while(index1<size1)
    {
        mergearray[mergeindex]=arr1[index1];
        mergeindex++;
        index1++;
    }
    while(index2<size2)
    {
        mergearray[mergeindex]=arr2[index2];
        mergeindex++;
        index2++;
    }
    printf("\narray merged in ascending order:")
    for(i=0;i<mergesize;i++)
    {
        printf("%d\t",mergearray[i]);

    }
    return 0;


}
