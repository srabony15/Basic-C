#include<stdio.h>
int main()
{
    int x,y,z;
    x=3,z=6;
    y=x>z ? x:z;
    printf("The y is:%d",y);
    return 0;
}
