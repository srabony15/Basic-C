#include<stdio.h>
int arr_max(int data[],int sz){
int i, max=data[0];
for(i=1;i<sz;i++){
    if(data[i]>max)
        max=data[i];
}
return max;
}
int arr_min(int data[],int sz){
int i,min=data[0];
for(i=1;i<sz;i++){
    if(data[i]<min)
        min=data[i];

}
return min;
}
