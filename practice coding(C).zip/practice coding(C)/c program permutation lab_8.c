#include<stdio.h>
int fact(int);
void main()
{
    int n, r, pr;
    printf("Enter a number n\n");
    scanf("%d",&n);
    printf("Enter a number r\n");
    scanf("%d",&r);
    pr=fact(n)/fact(n-r);
    printf("value of %d%d=%d\n",n,r,pr);
}
int fact(int n)
{
    int i,f=1;
    for(i=1;i<=n;i++)
    {
        f=f*i;
    }
    return f;
}


