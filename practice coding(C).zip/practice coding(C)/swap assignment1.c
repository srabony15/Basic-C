#include<stdio.h>
int main()
{
    int num1,num2,num3;

    printf("Enter the first number:");
    scanf("%d",&num1);

    printf("Enter the first number:");
    scanf("%d",&num2);

num3=num1;
    num1=num2;
    num2=num3;


    printf("\n after swapping,first number=%d",num1);
    printf("after swapping,second number=%d",num2);

    return 0;
}
