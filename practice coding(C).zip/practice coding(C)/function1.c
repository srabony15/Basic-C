#include<stdio.h>
void arr_swap(int arr[],int n)
{
    int x=n-1,c,temp;
    for(c=0;c<=(n/2);c++,x--)
    {
        temp=arr[c];
        arr[c]=arr[x];
        arr[x]=temp;
    }
}
int main()
{
    int arr[100],n,c;
    printf("How many numbers:");
    scanf("%d",&n);
    for(c=0;c<n;c++)
        scanf("%d",&arr[c]);
    arr_swap(arr,n);
    for(c=0;c<n;c++)
        printf("%d",arr[c]);
    return 0;
}
