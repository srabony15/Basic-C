#include<stdio.h>
int main()
{
    int i;
    printf("Enter Range 1 to 50:");
    for(i=1; i<=50; i++)
    {
        if (i%3==0 && i%5==0)
            printf("%d,",i);
    }
    return 0;
}
