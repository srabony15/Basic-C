#include<stdio.h>
int main()
{
    int x,y,z;
    x=3,z=6;

    y=x++ + x++;
    printf("The y is:%d\n",y);

    y=x>z? x:z;
    printf("The y is:%d\n",y);

    y=x&z;
    printf("The y is:%d\n",y);

    return 0;
}
