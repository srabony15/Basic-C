#include<stdio.h>
int main()
{
    char str[100],ch;
    int c=0;
    printf ("Enter a string:");
    fgets(str,sizeof(str),string);
    printf("Enter a character to find its frequency:");
    scanf("%c",&ch);
    for(int i=0;str[1] != '\0';++i)
    {
        if(ch==str[i])
            ++c;
    }
    printf("Frequency of %c=%d",ch,c);
    return 0;
}
