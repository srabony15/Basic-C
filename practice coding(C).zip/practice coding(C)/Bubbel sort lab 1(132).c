#include<stdio.h>
int main()
{
    int x[50],i,k,n,temp;
    printf("How many elements:");
    scanf("%d",&n);
    printf("Enter the elements:");
    for(i=0;i<n;i++)
        scanf("%d",&x[i]);
    for(i=0;i<n-1;i++)
    {
        for(k=0;k<n-1-i;k++)
        {
            if(x[k]>x[k+1])
                swap(x,k);
        }
    }
    printf("sorted array:");
    for(i=0;i<n;i++)
        printf("%d",x[i]);
    return 0;

}
void swap(int arr[],int k)
{
    int temp;
    temp=arr[k];
    arr[k]=arr[k+1];
    arr[k+1]=temp;
    return 0;
}




