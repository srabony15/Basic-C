#include<stdio.h>
int main()
{
    int b[10][10],d[10][10],row,col,r,c,sum[r][c];
    printf("Enter row and column number:");
    scanf("%d%d",&row,&col);
    for(r=0;r<row;r++){
        for(c=0;c<col;c++){
            scanf("%d",&b[r][c]);
        }
    }
    printf("Entered 1st matrix:\n");
    for(r=0;r<row;r++){
        for(c=0;c<col;c++){
            printf("%d",b[r][c]);
        }
        printf("\n");
    }
    printf("Enter row and column number:");
    scanf("%d%d",&row,&col);
    for(r=0;r<row;r++){
        for(c=0;c<col;c++){
            scanf("%d",&d[r][c]);
        }
    }
    printf("Entered 2nd matrix:\n");
    for(r=0;r<row;r++){
        for(c=0;c<col;c++){
            printf("%d",d[r][c]);
        }
        printf("\n");
    }
    printf("sum two matrix is:\n");
    for(r=0;r<row;r++){
        for(c=0;c<col;c++){
            sum[r][c]=b[r][c]+ d[r][c];
            printf("%d",sum[r][c]);
        }
        printf("\n");
    }
    return 0;
}
