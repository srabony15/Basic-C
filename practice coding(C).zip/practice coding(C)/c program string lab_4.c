#include<stdio.h>
#include<stdlib.h>
int main()
{
    char a[]="string";
    int i=0;
    while(a[i]!='\0')
    {
        printf("%c\n",*(a+i));
        i++;

    }
    return 0;
}
