#include<stdio.h>
int main()
{
    int n,arr[20],beg,end,mid,item,i,found=0;
    printf("Enter size:");
    scanf("%d",&n);
    printf("Enter array elements:");
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
    printf("Enter search item:\n");
    scanf("%d",&item);
    beg=0;
    end=n-1;
    while(beg<=end)
    {
        mid=(beg+end)/2;
        if(item<arr[mid])
        {
            end=mid-1;
        }
        else if(item>arr[mid])
        {
            beg=mid+1;
        }
        else if(item==arr[mid])
        {
            found=1;
            break;
        }
    }
    if(found==1)
    {
        printf("Found at location:%d\n",mid);
    }
    else
    {
        printf("Not found at location:%d\n");
    }
    return 0;
}
