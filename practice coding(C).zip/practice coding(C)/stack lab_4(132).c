#include<stdio.h>
#include<stdbool.h>
char maxsize=10;
char stack[100];
char top=NULL;
bool isempty()
{
    if(top==NULL)
        return true;
    else
        return false;
}
bool isfull()
{
    if(top==maxsize)
        return true;
    else
        return false;
}
int peek()
{
    return stack[top];
}
int pop()
{
    char data;
    if(!isempty())
    {
        data=stack[top];
        top=top-1;
        return data;

    }
    else
    {
        printf("stack is empty\n");
    }
}
int push(int data)
{
    if(!isfull())
    {
        top=top+1;
        stack[top]=data;
    }
    else
    {
        printf("stack is full\n");
    }
}
int main()
{
    char data;
    printf("Enter elements to insert in stack:");
    while(!isfull())
    {
        scanf("%d",&data);
        push(data);


    }
    printf("Element at top of the stack:%d\n",peek());
    printf("Element stack full:%s\n",isfull()?"true":"false");
    printf("stack empty:%s\n",isempty()?"true":"false");
    printf("Element:\n");
    while(!isempty())
    {
        char data = pop();
        printf("%d\n",data);
    }
    printf("stack full:%s\n",isfull()?"true":"false");
    printf("stack empty:%s\n",isempty()?"true":"false");
    return 0;
}
