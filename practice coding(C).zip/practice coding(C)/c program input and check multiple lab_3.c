#include<stdio.h>
int main()
{


int n,m;
printf("Enter any number:");
scanf("%d",&n);
m=n*3;
if(m/5||m/7)
{
    printf("condition is true: \n");

}
else
    printf("condition do not match: \n");
    return 0;
}
