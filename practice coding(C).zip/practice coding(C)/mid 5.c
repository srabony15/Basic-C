#include<stdio.h>
int main()
{
    int i,z;

    for(i=2;i<10;i++)
    {
        z=i*i;
        printf("%d-> %d\n",i,z);
    }
    return 0;
}
