#include<stdio.h>
int main()
{
    char name[30];
    int roll;
    float sub1;
    float sub2;
    float sub3;
    float sum;
    float score;
    printf("Enter the name:");
    scanf("%c",name);
    printf("Enter the roll:");
    scanf("%d",&roll);
    printf("Enter the marks of sub1:");
    scanf("%f",&sub1);
    printf("Enter the marks of sub2:");
    scanf("%f",&sub2);
    printf("Enter the marks of sub3:");
    scanf("%f",&sub3);
    sum=sub1+sub2+sub3;
    score=sum/3;
    printf("name is:%c",name);
    printf("roll is:%d",roll);
    printf("Marks is:%f",score);
    return 0;


}
