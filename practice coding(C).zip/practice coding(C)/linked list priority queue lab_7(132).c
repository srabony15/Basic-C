#include <stdio.h>

typedef struct n_node{
    int data;
    int priority;
    struct n_node *next;
}node;

node *start = NULL;
node *tail = NULL;

void enqueue (int item, int priority)
{
    node *temp = start;
    node *pre = NULL;

    node *newNode = (node*)malloc(sizeof(node));
    newNode->data = item;
    newNode->priority = priority;
    newNode->next = NULL;

    if (start == NULL)
    {
        start = newNode;
        newNode->next = NULL;
        tail = start;
        return;
    }

    if (newNode->priority < temp->priority)
    {
        newNode->next = temp;
        start = newNode;
        return;
    }

    while ((newNode->priority > temp->priority))
    {
        if (temp->next == NULL)
        {
            temp->next = newNode;
            tail = newNode;
            return;
        }

        pre = temp;
        temp =temp->next;
    }

    pre->next = newNode;
    newNode->next = temp;

    return;
}

int dequeue ()
{
    int result;
    if (start == NULL)
    {
        printf("Queue is already empty\n");
        return;
    }

    result = start->data;
    start = start->next;
    return result;
}

void print_queue ()
{
    node* temp = start;

    while (temp != NULL){
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

int main()
{
    int test, item, priority, result;

    printf("Type 1 to enqueue. 2 to dequeue. 3 to exit\n");

    while (1)
    {
        scanf("%d", &test);

        if (test == 1)
        {
            printf("Enter item and priority: ");
            scanf("%d%d", &item, &priority);
            enqueue (item, priority);
            print_queue ();
        }

        else if (test == 2)
        {
            result = dequeue();
            printf("Item dequeued is %d\n", result);
            print_queue ();
        }

        else if (test == 3)
            break;
    }

    return 0;
}
