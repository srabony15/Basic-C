#include<stdio.h>
int main()
{
    int a[10][10], row,col,r,c;
    printf("Enter row and column number:");
    scanf("%d%d",&row,&col);
    for(r=0;r<row;r++){
        for(c=0;c<col;c++){
            scanf("%d",&a[r][c]);
        }
    }
    printf("Emter row and column number:");
    scanf("%d,&[r][c]");
    int sum[row][col];
    printf("sum of the matrix:");
    for(r=0;r<row;r++){

    }
    for (c=0;c<col;c++){

    }



    sum[r][c]=[r][c]+[r][c];
    printf("%d",sum[r][c]);{
    }
    printf("\n");{
    }
    return 0;

}
