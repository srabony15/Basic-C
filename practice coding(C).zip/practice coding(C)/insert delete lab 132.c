#include <stdio.h>
#include <stdlib.h>
struct Node {
int data;
struct Node* next;
};
struct Node* head = NULL;
struct Node* newNode = NULL;
void printList(struct Node* n)
{
if(head == NULL){
printf("Empty List\n");
return;
}
while (n != NULL) {
printf(" %d ", n->data);
n = n->next;
}
}
void insertFirst(int data){
newNode = (struct Node*)malloc(sizeof(struct Node));
newNode->data = data;
newNode->next = head;
head = newNode;
}
void insertLast(int data){
newNode = (struct Node*)malloc(sizeof(struct Node));
newNode->data = data;
newNode->next = NULL;
if(head==NULL){
head = newNode;
return;
}
struct Node* ptr = head;
while(ptr->next!= NULL)
ptr=ptr->next;
ptr->next = newNode;
}
void insertSorted(int data){
if((head==NULL) || (head->data > data)){
insertFirst(data);
return;
}
newNode = (struct Node*)malloc(sizeof(struct Node));
newNode->data = data;
newNode->next = NULL;
struct Node* prePtr = NULL;
struct Node* ptr = head;
while((ptr->next!= NULL) && (ptr->data < data)){
prePtr = ptr;
ptr = ptr->next;
}
if(ptr->data > data){
newNode->next = ptr;
prePtr->next = newNode;
return;
}
ptr->next = newNode;
}
void deleteLL(int data){
if(head==NULL){
printf("\nEmpty List");
return;
}
if(head->data == data){
head = head->next;
return;
}
struct Node* prePtr = NULL;
struct Node* ptr = head;
while(ptr->data != data){
if(ptr->next == NULL){
printf("Item not found\n");
return;
}
prePtr = ptr;
ptr = ptr->next;
}
prePtr->next = ptr->next;
}
int main(){
int i, num;
printf("Enter five numbers: ");
for(i=0; i<5; i++){
scanf("%d", &num);
insertSorted(num);
}
printList(head);
for(i=0; i<5; i++){
printf("\nEnter item to delete: ");
scanf("%d", &num);
deleteLL(num);
printList(head);
}
return 0;
}
