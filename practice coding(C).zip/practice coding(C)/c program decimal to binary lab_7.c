#include<stdio.h>
#include<math.h>
long decimaltobinary(int decimalnum)
{
    long binarynum=0;
    int temp,temp=1;
    while(decimalnum!=0)
    {
        temp=decimalnum%2;
        decimalnum=decimalnum/2;
        binarynum=binarynum+temp*temp;
        temp=temp*10;
    }
    return binarynum;
}
int main()
{
    int decimalnum;
    printf("Enter a decimal number:");
    scanf("%d",&decimalnum);
    printf("Equivalent binary number is :%1d",decimaltobinary(decimalnum));
    return 0;
}
