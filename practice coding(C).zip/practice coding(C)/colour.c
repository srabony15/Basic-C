#include<stdio.h>
int main()
{
    char a,b,g;
    char x;
    scanf("%c",&x);

    if(x=='r')
        printf("red");
    else if(x=='b')
        printf("blue");
    else if(x=='g')
        printf("green");
    else
        printf("nothing found");
    return 0;



}
