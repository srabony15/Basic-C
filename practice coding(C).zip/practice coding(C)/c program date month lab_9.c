#include<stdio.h>
int main()
{
    typedef struct{
    int day;
    int month;
    int year;
    } date;
    date date1;
    printf("Enter day:");
    scanf("%d",&(date1.day));
    pritf("Enter month:");
    scanf("%d",(date1.month));
    printf("Enter year:");
    scanf("%d",&(date1.year));
    printf("date1 %d/%d/%d",date1.day,date1.month,date1.year);
    return 0;
}
