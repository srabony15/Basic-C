#include<stdio.h>
int main()
{
    int arr[50], copy[50], c , n;
    printf("How many elements:");
    scanf("%d",&n);
    for(c=0;c<n;c++)
        scanf("%d",arr+c);
    for(c=0;c<n;c++)
        *(copy+c)= *(arr+c);
    for(c=0;c<n;c++)
        printf("%d",(copy+c));
    return 0;
}
