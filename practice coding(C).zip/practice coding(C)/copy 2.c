#include<stdio.h>
int main()
{
    int n;
    printf("Enter the number of element:");
    scanf("%d",&n);

    int a[n],b[n];
    printf("Enter the array element:");
    for(int i=0,j=n-1;i<n;i++,j--)
    {
        scanf("%d",&a[i]);
        b[j]=a[i];
    }
    for (int i=0;i<n;i++)
    {
        printf("%d",b[i]);
    }
    return 0;
}
