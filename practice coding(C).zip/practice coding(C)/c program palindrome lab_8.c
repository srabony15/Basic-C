#include<stdio.h>
#include<string.h>
int main()
{
    char ch[100],rs[100];
    scanf(ch);
    strcpy(ch,rs);
    int b=strlen(ch);
    for(int i=0;i<b/2;i++)
    {
        int temp=ch[i];
        ch[i]=ch[b-i-1];
        ch[b-i-1]=temp;
    }
    if(strcmp (ch,rs) == 0)
        printf("palindrome");
    else
        printf("Not");
    return 0;
}










