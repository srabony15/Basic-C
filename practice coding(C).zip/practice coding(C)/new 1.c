#include<stdio.h>
int main()
{
   float num1=10.5;
   double num2=10.525;
   char ch='a';
   printf("num1=%f\n",num1);
   printf("num2=%1f\n",num2);
   printf("ch=%c",ch);
   return 0;

}
