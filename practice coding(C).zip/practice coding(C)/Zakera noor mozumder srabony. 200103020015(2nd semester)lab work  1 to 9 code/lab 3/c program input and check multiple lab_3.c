#include<stdio.h>
int main()
{


int n;
printf("Enter any number:");
scanf("%d",&n);
if(n*3 && n%5==0)
{
    printf("number is matched: \n");

}

else if(n*3 && n%7==0)
    printf("number is matched: \n");
else
	printf("number does not matched");
return 0;	
}

