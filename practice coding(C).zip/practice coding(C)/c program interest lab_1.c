#include<stdio.h>
int main()
{
    float P,T,R,I;
    P=3000;
    T=2;
     R=5.5;
     I=(P*T*R)/100;
    printf("I is=%0.2f",I);
    return 0;
}
