#include<stdio.h>
int main()
{
    int n,i,fact,k;
    printf("Enter the number:");
    scanf("%d",&n);
    printf("prime numbers are:");
    for(i=1; i<=n; i++)
    {
        fact=0;
        for(k=1; k<=n; k++)
        {
            if(i%k==0)
                fact++;
        }
        if(fact==2)
            printf("%d" ,i);
    }
    printf("\n");
    return 0;
}
