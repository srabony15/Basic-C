#include<stdio.h>
#include<conio.h>
int main()
{
    int i,n,s=0;
    scanf("%d",&n);
    do
    {
        printf("Value of variable s is %d\n",n);


        s=s+i*i;

    }
    while( i<=n);
    return 0;
}
