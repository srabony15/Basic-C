#include<stdio.h>
int main()
{
    int cse113,cse114,math101,phy102,eng202;
    float per;
    printf("Enter five sub marks:");
    scanf("%d%d%d%d%d",&cse113,&cse114,&math101,&phy102,&eng202);
    per=(cse113+cse114+math101+math101+eng202)/5.0;

    printf("percentage=%.2f\n",per);
    if(per>=80)
        printf("grade a+");

     else if(per>=79)

    printf("grade A");
    else if(per>=59)
        printf("grade B");
    else if(per>=49)
        printf("grade C");
    else if(per>=39)
        printf("grade D");
    else
        printf("grade F");
    return 0;

}
