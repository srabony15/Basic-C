#include<stdio.h>
int main()
{
    int count, maxcount=0,n,i,j;
    scanf("%d",&n);
    int A[n];
    for(i=0; i<n; i++)
        scanf("%d",&A[i]);
    i=0;
    while(i<n)
    {
        count=1;
        j=i+1;
        while(j<n)
        {
            if(A[i]==A[j])
                count++;
            j++;
        }
        if(count>maxcount)
            maxcount=count;

        i++;
    }
    i=0;
    j=0;
    while(i<n)
    {
        count=1;
        j=i+1;
        while(j<n)
        {
            if(A[i]==A[j])
                count++;

            j++;
        }
        if(count==maxcount)
            printf("%d %d\n",A[i],maxcount);
        i++;
    }



}
