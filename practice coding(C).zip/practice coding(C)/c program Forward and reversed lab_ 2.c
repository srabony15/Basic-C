#include<stdio.h>
int main()
{
    int d,e,f;
    printf("Enter the three integer:");
    scanf("%d%d%d",&d,&e,&f);
    printf("\n The forward order:%d%d%d",d,e,f);
    printf("\n The reverse order:%d%d%d\n",f,e,d);
    return 0;
}
