#include<stdio.h>
int main()
{
    int i,arr[100],n,pos_sum=0,neg_sum=0;
    printf("Enter the number of the array:");
    scanf("%d",&n);
    printf("Enter the value of the array:\n");
    for(i=0;i<n;i++)
    {
        printf("Element %d:",i);
        scanf("%d",&arr[i]);
    }
    for(i=0;i<n;i++)
    {
        if(arr[i]<0)
        {
            neg_sum+=arr[i];
        }
        else
        {
            pos_sum+=arr[i];
        }

    }
    printf("\n\n the sum of positive element is :%d\n",pos_sum);
    printf("The sum of negative element is :%d\n",neg_sum);
    return 0;
}
